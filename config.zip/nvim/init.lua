-------------------------------
-- Import Lua modules
-------------------------------
require('settings') -- settings
require('keymaps')  -- keymaps
require('plugins')  -- plugins

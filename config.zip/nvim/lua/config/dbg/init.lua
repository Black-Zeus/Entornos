require('telescope').load_extension('dap')
require('dbg.rust')
require('dbg.python')

local sidebar = require("sidebar-nvim")
sidebar.setup({
    open = false
})

require("sessions").setup({
    session_filepath = ".nvim/session"
})

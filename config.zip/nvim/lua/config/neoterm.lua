require('neo-term').setup {
   split_on_top = false,
   split_size = 0.3,
}

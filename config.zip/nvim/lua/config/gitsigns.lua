-----------------------------------------------------------
-- Gitsigns configuration file
-----------------------------------------------------------

-- Plugin: gitsigns.nvim
-- https://github.com/lewis6991/gitsigns.nvim

require('gitsigns').setup()

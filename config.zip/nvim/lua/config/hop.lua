require("hop").setup({
    keys = 'etovxqpdygfblzhckisuran'
})

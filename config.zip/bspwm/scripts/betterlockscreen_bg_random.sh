#!/bin/bash

# Ruta de la carpeta con las imágenes
IMAGE_DIR="~/WallPapers/"

# Tiempo en segundos para cambiar la imagen
TIMEOUT=15

# Lista de archivos de imagen en la carpeta
IMAGE_LIST=($(ls -1 $IMAGE_DIR/*.{jpg,jpeg,png,gif}))

# Función para seleccionar una imagen aleatoria
function select_random_image {
  local length=${#IMAGE_LIST[@]}
  local index=$((RANDOM % $length))
  echo ${IMAGE_LIST[$index]}
}

# Función para cambiar el fondo de pantalla con set-wallpaper
function set_wallpaper {
  local image=$(select_random_image)
  /usr/bin/set-wallpaper "$image"
}

# Bucle infinito para cambiar la imagen cada cierto tiempo
while true
do
  set_wallpaper
  sleep $TIMEOUT
done

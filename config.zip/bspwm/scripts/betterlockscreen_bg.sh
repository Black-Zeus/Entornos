#!/bin/bash
while true
do
  feh --randomize --bg-fill ~/WallPapers/*
  sleep 15s
done
